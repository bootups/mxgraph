/**
 * Copyright (c) 2008, Gaudenz Alder
 */
package com.mxgraph.layout.orthogonal.model;

/**
 *
 */
public class mxPointSequence
{

}
